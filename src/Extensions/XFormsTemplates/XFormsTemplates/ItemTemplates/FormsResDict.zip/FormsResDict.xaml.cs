﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $rootnamespace$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class $safeitemname$ : ResourceDictionary
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
